# To execute the training program. The argument must be a number inclusively in 0-9 
python exe.py
or
# Using 0 as example argument, may be replaced
python mixed_training_cv.py 0
