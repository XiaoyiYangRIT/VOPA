Installation:  
conda create -n apple_data python==3.7  
pip install sklearn  
pip install pandas  
pip install numpy  
pip install tensorflow or pip install tensorflow-gpu (if gpu available)
pip install opencv-python  



Run:  
python mixed_training.py -d path/to/dataset